(function() {
    var selection = window.getSelection();
    return selection.toString().length > 0;
})();