(function() {
    if (window.iTermReaderMode) {
        return window.iTermReaderMode.enter();
    }
    return false;
})()
