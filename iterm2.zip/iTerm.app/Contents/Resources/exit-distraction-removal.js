(function() {
    if (window.iTermDistractionRemoval) {
        return window.iTermDistractionRemoval.exit();
    }
    return false;
})()